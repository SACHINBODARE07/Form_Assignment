const addNum = (a, b) => {
    console.log(a + b)
}

module.exports = { addNum };