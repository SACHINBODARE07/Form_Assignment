const mongoose = require("mongoose")

const connectDb = async ()  => {
    const connection = await mongoose.connect("mongodb://localhost:27017")
    if(connection){
        console.log("Connect to Db")
    }else{
        console.log("Coonection is failed to Db")
    }
}

module.exports = {connectDb}